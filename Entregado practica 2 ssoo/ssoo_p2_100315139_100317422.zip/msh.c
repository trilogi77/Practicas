/*-
 * msh.c
 *
 * Minishell C source
 * Show how to use "obtain_order" input interface function
 *
 * THIS FILE IS TO BE MODIFIED
 */

#include <stddef.h>			/* NULL */
#include <stdio.h>			/* setbuf, printf */
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
extern int obtain_order();		/* See parser.y for description */

int main(void)
{
	char ***argvv;
	int command_counter;
	int num_commands;
	int args_counter;
	char *filev[3];//
	int bg;
	int ret;
    int fd[2];
    int fd2[2];
	setbuf(stdout, NULL);			/* Unbuffered */
	setbuf(stdin, NULL);

	while (1) 
	{
		fprintf(stderr, "%s", "msh> ");	/* Prompt */
		ret = obtain_order(&argvv, filev, &bg);
		if (ret == 0) break;		/* EOF */
		if (ret == -1) continue;	/* Syntax error */
		num_commands = ret - 1;		/* Line */
		if (num_commands == 0) continue;	/* Empty line */

			/*ca
			 * COMIENZO DE LA PARTE A ELIMINAR
			 * LAS LINEAS QUE A CONTINUACION SE PRESENTAN SON SOLO
			 * PARA DAR UNA IDEA DE COMO UTILIZAR LAS ESTRUCTURAS
			 * argvv Y filev. ESTAS LINEAS DEBERAN SER ELIMINADAS.
			 */		
	    pipe(fd);
		int status;
		int pidls;

	    /*Recoge en historial el valor de la variable de entorno MSH_HISTORY*/
	    char* historial = getenv("MSH_HISTORY");


        /*Si es null se le da un valor por defecto*/
        if (historial==NULL){
            historial="msh_history.log";
        }
        int historial_write = open(historial,O_APPEND|O_WRONLY);
        if(historial_write==-1){
           historial_write=open(historial, O_CREAT|O_WRONLY, S_IWUSR|S_IRUSR);
        }
 		
	 	if(argvv[1]==NULL){	//comprueba que si hay solo un comando
	 		pidls= fork();	//hace un fork
	 		switch (pidls){		//switch que depende del pid
		 		case(-1): 		//caso -1 error en el fork
		 			perror("Error en el fork");
		 			exit (-1);
		 		case(0):	//caso 0, caso de hijo
		 			 if (strcmp(argvv[0][0],"myhistory")==0) {

               			 execlp("cat","cat",historial,NULL);
          			 }
					if (filev[0]!=NULL){ //si hay fichero de entrada entra en este if
			 		 	close (STDIN_FILENO);		
						int df = open(filev[0], O_RDONLY); //abre el fichero en modo lectura
			 			execvp(argvv[0][0],argvv[0]); //ejecuta el comando
			       	 	close (df);	//cierra el fichero
		 			}
		     		if (filev[1]!=NULL){	//si hay fichero de salida entra en este if
						close(STDOUT_FILENO);
						int df2 = open(filev[1], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
						execvp(argvv[0][0],argvv[0]);	//ejecuta el comando
				    	close(df2);	//cierra el fichero
					}
					if (filev[2] != NULL){
						close(2);		//para que guarde la salida de error en el fichero
						int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
						execvp(argvv[0][0],argvv[0]);	//ejecuta el comando
				    	close(df3);	//cierra el fichero
					}
		       		else{	//en el resto de casos
		         		execvp( argvv[0][0], argvv[0]); //ejecuta el comando
			 		}
			 		break;
	 			default:	//caso del padre
	 				if(bg!=1){	//si no es ejecutado en background
		 				wait(&status);	//espera al hjo
		 				break;
		 			}
		 			else{		//si se ejecuta en background
		 				printf("%d\n" ,getpid());	//escribe pid del hijo
		 				break;
		 			}
			}
		}
		if (argvv[1]!=NULL&&argvv[2]==NULL){	//si hay un segundo comando
			for (command_counter = 0; command_counter < num_commands; command_counter++){
				pidls= fork();	//hace un fork
				if(command_counter==0){
					switch (pidls) {
						 case -1:
							perror("Error al hacer el fork");
						case 0:
							close(fd[0]) ;                
							             
							dup2(fd[1], STDOUT_FILENO) ;
							close(fd[1]);
							if (filev[0]!=NULL){ //si hay fichero de entrada entra en este if
					 		 	close (STDIN_FILENO);		
								int df = open(filev[0], O_RDONLY); //abre el fichero en modo lectura
					 			execvp(argvv[command_counter][0],argvv[command_counter]); //ejecuta el comando
					       	 	close (df);	//cierra el fichero
				 			}
				 			if (filev[2] != NULL){
								close(2);		//para que guarde la salida de error en el fichero
								int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df3);	//cierra el fichero
							}
							


							execvp(argvv[command_counter][0], argvv[command_counter]);
							
						default:           
						  break;
				    }
				}
				
				if(command_counter==1){				
			        switch (pidls) {
						case -1:
							  perror("Error al hacer el fork");

						case 0:             

							close(fd[1]);                   
							             
							dup2(fd[0], STDIN_FILENO) ;
							close(fd[0]) ;

							
				     		if (filev[1]!=NULL){	//si hay fichero de salida entra en este if
								close(STDOUT_FILENO);
								int df2 = open(filev[1], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df2);	//cierra el fichero
							}
							if (filev[2] != NULL){
								close(2);		//para que guarde la salida de error en el fichero
								int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df3);	//cierra el fichero
							}
							

							else{
								
								execvp(argvv[command_counter][0], argvv[command_counter]);
							}
						default: 
							while(wait(&status)==pidls);
							close(fd[0]);
							close(fd[1]);
							
							break;
			        }
				}
			}
		}
		
		

		if(argvv[1]!=NULL&&argvv[2]!=NULL){
			for (command_counter = 0; command_counter < num_commands; command_counter++){
				pidls=fork();
				if(command_counter==0){
					switch (pidls) {
						 case -1:
							perror("Error al hacer el fork del comando 1");
						case 0:
							close(fd[0]);
							close(fd2[0]);
							close(fd2[1]); 
							dup2(fd[1], STDOUT_FILENO) ;
							close(fd[1]) ;
							if (filev[0]!=NULL){ //si hay fichero de entrada entra en este if
					 		 	close (STDIN_FILENO);		
								int df = open(filev[0], O_RDONLY); //abre el fichero en modo lectura
					 			execvp(argvv[command_counter][0],argvv[command_counter]); //ejecuta el comando
					       	 	close (df);	//cierra el fichero
				 			}
				 			if (filev[2] != NULL){
								close(2);		//para que guarde la salida de error en el fichero
								int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df3);	//cierra el fichero
							}
							

						
							execvp(argvv[command_counter][0], argvv[command_counter]);
							
						default:           
						  break;
				    }
				}
				
				if(command_counter==1){				
			        switch (pidls) {
						case -1:
							  perror("Error al hacer el fork del comando 2");

						case 0:             
							close(fd2[0]);       
							dup2(fd2[1], STDOUT_FILENO);
							close(fd2[1]);           
							close(fd[1]) ;              
							dup2(fd[0], STDIN_FILENO);
							close(fd[0]);
							if (filev[2] != NULL){
								close(2);		//para que guarde la salida de error en el fichero
								int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df3);	//cierra el fichero
							}
	
							

							execvp(argvv[command_counter][0], argvv[command_counter]);	
							
								
								
						default:
						close(fd[0]);
						close(fd[1]); 
							break;
					}
				}
				if(command_counter==2){
					switch (pidls) {
						case -1:
							  perror("Error al hacer el fork del comando 3");

						case 0:             
							close(fd[0]);
							
							close(fd[1]);

							close(fd2[1]);

							dup2(fd2[0], STDIN_FILENO) ;
							close(fd2[0]); 
						
							
				     		if (filev[1]!=NULL){	//si hay fichero de salida entra en este if
								close(STDOUT_FILENO);
								int df2 = open(filev[1], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df2);	//cierra el fichero
							}
							if (filev[2] != NULL){
								close(2);		//para que guarde la salida de error en el fichero
								int df3 = open(filev[2], O_CREAT| O_WRONLY| O_TRUNC, 0666); //abre el fichero en modo escritura en caso de no existir lo crea en caso de existir lo trunca
								execvp(argvv[command_counter][0],argvv[command_counter]);	//ejecuta el comando
						    	close(df3);	//cierra el fichero
							}
							else{
								execvp(argvv[command_counter][0], argvv[command_counter]);	
							}
						default: 
							close(fd[0]);
							close(fd[1]);
							close(fd2[0]);
							close(fd2[1]);
							break;

					}	
				}
			}
		}
		/*Variables utilizadas en history*/
		int file;
		char buffer[1000000];
		char salto_de_linea[2];
		char barra_separadora[4];
		char indicador_bg[4];
		char indicador_in[4];
		char indicador_out[4];
		char indicador_err_out[5];
		char espacio[2];
		int limpieza;
		//Copia en los array de strings
		strcpy(salto_de_linea, "\n");
		strcpy(barra_separadora,"|");
		strcpy(indicador_bg," &");
		strcpy(indicador_in, " < ");
		strcpy(indicador_out," > ");
		strcpy(indicador_err_out," >& ");
		strcpy(espacio," ");
		//Abrime el fichero en el que se va a escribir el historial y asigna los permisos. Si no existe se crea
		file = open (historial,O_APPEND|O_WRONLY);
		if (file==-1) {
		    file=open(historial, O_CREAT|O_WRONLY, 0666);
		}
		if (file==-1) {
		    perror("Error al abrir el fichero del historial");
		}
		for (command_counter = 0; command_counter < num_commands; command_counter++) {
		    for (args_counter = 0; (argvv[command_counter][args_counter] != NULL); args_counter++){
		        strcpy(buffer,argvv[command_counter][args_counter]);
		        int size=sizeof(argvv[command_counter][args_counter])+30;
		        
		        /*Escribimos el contenido del buffer en el fichero*/
		        errno=write(file, &buffer, size);
		        if (errno<0) {
		            perror("Error al escribir un comando en el historial: ");
		        }
		        if (argvv[command_counter][args_counter+1]!=NULL) {
		            errno=write(file, &espacio, 1);
		        }
		        if (errno<0) {
		            perror("Error al escribir espacio en el historial: ");
		        }
		        /*Limpiamos el buffer para futuros usos*/
		        for (limpieza=0; limpieza<sizeof(buffer); limpieza++){
		            strcpy(&buffer[limpieza],"\0");
		        }
		    }
		    if (num_commands>command_counter+1){/* Imprimimos "|" cuando se hacen pipes*/
		        errno=write(file, &barra_separadora, 2);
		        if (errno<0) {
		            perror("Error al escribir '|' en el historial: ");
		        }
		    }
		    else{
		        /*Para redirecciones de entrada, imprimimos "<" y luego el fichero*/
		        if (filev[0]!=NULL) {
		            strcpy(buffer,filev[0]);
		            errno= write(file, &indicador_in, 2);
		            if (errno<0) {
		                perror("Error al escribir '<' en el historial: ");
		            }
		            errno=write(file, &buffer,sizeof(filev[0])+30);
		            if (errno<0) {
		                perror("Error al escribir el fichero de entrada en el historial: ");
		            }
		            for (limpieza=0; limpieza<sizeof(buffer); limpieza++){
		                strcpy(&buffer[limpieza],"\0");
		            }
		        }
		        /*Para redirecciones de salida, imprimimos ">" y luego el fichero*/
		        if (filev[1]!=NULL) {
		            strcpy(buffer,filev[1]);
		            errno=write(file, &indicador_out, 2);
		            if (errno<0) {
		                perror("Error al escribir '>' en el historial: ");
		            }
		            write(file, &buffer,sizeof(filev[1])+30);
		            if (errno<0) {
		                perror("Error al escribir el fichero de salida en el historial: ");
		            }
		            for (limpieza=0; limpieza<sizeof(buffer); limpieza++){
		                strcpy(&buffer[limpieza],"\0");
		            }
		        }
		        /*Para redirecciones de salida de error, imprimimos ">& y luego el fichero*/
		        if (filev[2]!=NULL) {
		            strcpy(buffer,filev[2]);
		            errno=write(file, &indicador_err_out, 2);
		            if (errno<0) {
		                perror("Error al escribir '>&' en el historial: ");
		            }
		            errno=write(file, &buffer,sizeof(filev[2])+30);
		            if (errno<0) {
		                perror("Error al escribir el fichero de salida de error en el historial: ");
		            }
		            for (limpieza=0; limpieza<sizeof(buffer); limpieza++){
		                strcpy(&buffer[limpieza],"\0");
		            }
		        }
		        /*Si es background, se imprime "&". A continuacion se salta de linea*/
		        if (command_counter==num_commands-1){
		            if(bg){
		                errno=write(file,&indicador_bg,2);
		                if (errno<0) {
		                    perror("Error al escribir '&' en el historial: ");
		                }
		            }
		            errno=write(file, &salto_de_linea, 2);
		            if (errno<0) {
		                perror("Error al escribir el salto de linea en el historial: ");
		            }
		        }
		    }
		}
		/*Cerramos el fichero*/
		errno=close(file);
		if (errno<0) {
		    perror("Error al cerrar el fichero del historial: ");
		}
	}



		/*for (command_counter = 0; command_counter < num_commands; command_counter++) 
		{
			for (args_counter = 0; (argvv[command_counter][args_counter] != NULL); args_counter++)
			{
				printf("%s ", argvv[command_counter][args_counter]);
			}
			printf("\n");
		}*/
	
		/*if (filev[0] != NULL) printf("< %s\n", filev[0]); IN 

		if (filev[1] != NULL) printf("> %s\n", filev[1]); OUT 
	
		if (filev[2] != NULL) printf(">& %s\n", filev[2]); ERR 
	
		if (bg) printf("&\n");*/

	/*
	 * FIN DE LA PARTE A ELIMINAR

	 */
	
	 //fin while 

	return 0;
} //fin main

