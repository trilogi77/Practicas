#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char * argv[]){

	// Check parameters introduced by the user
	if(argc != 3){
		printf("Syntax error. Correct syntax is:\n");
		printf("\t%s <file1> <file2>\n",argv[0]);		

		return -1;
	}
int df1 = open(argv[1], O_RDONLY);		/*abre fichero 1 y comprueba que no haya error*/
if (df1<0){
	perror ("no se puede abrir el fichero 1\n");
	return -1;
}
int df2 = open (argv[2], O_RDONLY);		/*abre fichero 2 y comprueba que no haya error*/
if (df2<0){
	perror ("no se puede abrir el fichero 2\n");
	close(df1);
	return -1;
}
int iguales=0;
char c1, c2;
while(iguales==0){					/*bucle que compara las lecturas de ambos documentos*/
	int r1 = read(df1, &c1, 1);
	int r2 = read(df2, &c2, 1);

	if(r1<0){
		perror("error al leer fichero 1\n");
		break;
	}
	if(r2<0){
		perror("error al leer fichero 2\n");
		break;
	}
	if(r1==0 && r2==0){
		printf("los ficheros son iguales\n");
		break;

	}

	if (c1==c2){
		iguales=0;
	

	}
	
	if(c1!=c2){
		
		printf ("los fiheros son diferentes\n");
		iguales=1;
	}

}
	int cer1= close (df1);  /*cierra ambos documentos*/
	if(cer1<0){
		perror("error al cerrar fichero 1");
		return -1;
	}
	int cer2=close (df2);
	if(cer2<0){
		perror("error al cerrar fichero 2");
		return -1;
	}

	return 0;

}


