#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	/* If less than four arguments (argv[0] -> program, argv[1] -> number of bytes to display, argv[2] -> input file, argv[3] ->  output file) print an error y return -1 */
	if(argc != 4)
	{
	    printf("Invalid number of arguments\n");
	    printf("\t%s <N> <file1> <file2>\n", argv[0]);		
	    return -1;
	}

	int df1 = open(argv[2], O_RDONLY);			/* abre fichero 1 y comprueba que se abre bien*/
	if (df1<0){
	perror ("no se puede abrir el fichero 1\n");
	return -1;
}
	int df2 = open (argv[3], O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR|S_IWUSR);  /*abre fichero 2 y comrpueba que se abre bien*/
	if (df2<0){
	perror ("no se puede abrir el fichero 2\n");
	close(df1);
	return -1;
}
	int contador= 0;
	int fin= atoi(argv[1]);
	char c1;
	

	/*Bucle que escribe en el fichero 2 los bits del fichero 1*/
	while (contador<fin){		
		int r1 = read(df1, &c1, 1);		/*lee fichero 1 y escribe en fichero 2 y hace bucle hasta que acabe los bits que se le han dico al programa*/
		
		int r2 = write(df2, &c1, 1);
		
		if(r1<0){
		perror("error al leer fichero 1\n");
		break;
		}
		if(r2<0){
		perror("error al escribir fichero 2\n");
		break;
		}
		if(r1==0){
		break;
		}
	contador=contador+1;


	}
	close (df1);
	close (df2);
	int df3 = open(argv[3], O_RDONLY); 	/*vuelvo a abrir el ficher 2*/
	contador=0;
  	/* Bucle para imprimir el fichero 2*/

	while (contador<fin){	
		int r1 = read(df3, &c1, 1);
		
		if(r1<0){
		perror("error al leer fichero 2\n");
		break;
		}
		if(r1==0){
		break;
		}
		printf("%c",c1);
		contador=contador+1;
	}
	close (df3);
	printf("\n");
	return 0;
}

