#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>

int main(int argc, char *argv[])
{
	/* If less than two arguments (argv[0] -> program, argv[1] -> directory to search) print an error y return -1 */
	if(argc < 2)
	{
		printf("Too few arguments\n");
        	return -1;
	}

	/* Include your code from here */

	DIR *dir=opendir(argv[1]);  /* abre directorio*/
	struct dirent *posicion;  /* crea estructura para saber la posición de memoria en la que está*/

		if (dir==NULL){				/*comprueba que el directorio se abrá bien*/
	perror ("no se puede abrir el directorio\n");
	return -1;
}
	
	
	while (	(posicion= readdir(dir))!=NULL){  /* bucle que imprime el nombre del fichero de la dirección de memoria en la que esté la estructura*/

	printf("%s\n", posicion->d_name);
	
}
	closedir(dir); 
	return 0;
}
